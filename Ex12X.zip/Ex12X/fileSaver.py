"""- Store each entry in a file (fasta stlye) in a given directory with the uniprot ID as filename
- check if file is already in directory, if yes pass if no then create """

import os

scrapeDic